/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package osvm;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author naqui
 */
public class Process {
        public OSVM m = new OSVM();
        public PCB processcontrolblock;
        public int memoryval = 0;
        public short datasize = 0;
        public int codesize;
        public FileInputStream fileIS;
        public int startLocation;
        public int endLocation;
        
        public  void main(String[] args) throws FileNotFoundException, IOException {
                String filename = "power";
                initialiseProcess(filename);
                //Load data
                addPageToPageTable();
                //Codes in mmory loadng
                loadCodes(filename);
                
                fileIS.close();

//priority queues
                
        }

        public Process() {
        }
        

        public void initialiseProcess(String nameOfFile) throws FileNotFoundException, IOException{
                processcontrolblock = new PCB();
                FileInputStream fileIS = new FileInputStream(new File(nameOfFile));
                processcontrolblock.pname = nameOfFile;

                Byte priority = (byte) fileIS.read(); //read priority
                if (priority >= 0 && priority < 32) {
                        processcontrolblock.ppriority = priority;
                }
                
                byte secondbyte = (byte) fileIS.read(); //read process id
                byte thirdbyte = (byte) fileIS.read(); //read process id

                processcontrolblock.pid = Bytetoshort(secondbyte, thirdbyte);
                //int processid = processcontrolblock.pid;

                byte fourthbyte = (byte) fileIS.read(); //read datasize
                byte fifthbyte = (byte) fileIS.read(); // read datasize

                processcontrolblock.psize = Bytetoshort(fourthbyte, fifthbyte);
                datasize = processcontrolblock.psize;
                fileIS.skip(3);
        }
        
        public  void loadCodes(String filename) throws IOException{
//                codesize = 0;
//                while (fileIS.read() != -1) {
//                        codesize = codesize + 1;
//                }
                //Why not codesize becz code counter is initialised in loadmemory function
                m.loadMemory(filename,  8 + datasize);
        }
        
        public  void addPageToPageTable() throws IOException{
                processcontrolblock.data_pagetable = new PageTable();
                int count = 0 ;
                for (int i = memoryval; i <= memoryval + datasize; i++) {
                        m.memory[i] = (byte) fileIS.read();
                        if (i % 128 == 0) {
                                processcontrolblock.data_pagetable.AddEntry((byte) m.memory[i], (byte) m.memory[i + 127]);
                        }
                        count = i;
                }
                //IDK samajh nahi arha hai
                //we should hardcode memval to 128
                memoryval = memoryval + datasize;
                if (memoryval % 128 != 0) {
                        memoryval = (memoryval) + (128 - (memoryval % 128));
                }
                startLocation = 0;
                endLocation = count;
        }
        
        public  short Bytetoshort(byte Fbyte, byte Sbyte) { //concat two bytes into short
                short temp = (short) (Fbyte * 256);
                temp = (short) (temp + Sbyte);
                return temp;
        }

}
