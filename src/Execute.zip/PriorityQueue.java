/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package osvm;

/**
 *
 * @author Ashad Nadeem
 */
public class PriorityQueue<Process> {
        Node head;
        
        public void enqueue(PCB proc){
                if(head==null || head.data.ppriority > proc.ppriority){
                        //if no node or process has higher piority from head.
                        Node temp = new Node(proc);
                        temp.next = head;
                        head = temp;
                }else{
                        //traverse the place to fit the pcb
                        Node curr = head;
                        Node temp = new Node(proc);
                        while(curr.next != null && curr.next.data.ppriority < temp.data.ppriority){
                                curr = curr.next;
                        }
                        temp.next = curr.next;
                        curr.next = temp;
                }
        }
        public PCB dequeue(){
                //if no pcb in the queue then return null
                if (head == null){
                        return null;
                }else{
                        //else return the head and make the next one head
                        Node temp = head;
                        head =  head.next;
                        return temp.data;
                }
        }
        
}
