/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package osvm;

import java.io.*;
import java.util.ArrayList;

/**
 *
 * @author Ashad Nadeem
 */
public class Execute { //class architecture
//register reg=new register();

        OSVM mainmem = new OSVM();
        boolean carry, zero, sign, overflow;
        int i = 0;
        int p = 0;
//pagetable codetableinCPU;
//pagetable datatableinCPU;
        Process p1;
        PriorityQueue<Process> q1 = new PriorityQueue<Process>();  // waiting ArrayList
        PriorityQueue<Process> q2 = new PriorityQueue<Process>(); //ArrayList for GUI
        PriorityQueue<Process> sp = new PriorityQueue<Process>(); //ArrayList for summary process
        PriorityQueue<Process> blk = new PriorityQueue<Process>(); //ArrayList for block process

        Execute() throws Exception { //contructor
                carry = false;
                zero = false;  //default value of flag register bits
                sign = false;
                overflow = false;
        } // constructor ends

        void load(String filename) throws Exception { //loads file
                p1 = new Process();
                p1.initialiseProcess(filename);
                String pid = String.valueOf(p1.processcontrolblock.pid);
                String log = "Process ID " + pid + " is loaded";
                mklogtxt(log);
                q1.enqueue(p1.processcontrolblock);
                q2.enqueue(p1.processcontrolblock);
                sp.enqueue(p1.processcontrolblock);
        } //file loading ends
void execute(Process pro) throws Exception {
                pro.pcb.reg.set_spl_reg((short) 0, (short) 0);     //update gen purpose register
                pro.pcb.reg.set_spl_reg((short) 1, (short) 0);
                pro.pcb.reg.set_spl_reg((short) 2, (short) pro.pcb.getcodesize());
                pro.pcb.reg.set_spl_reg((short) 3, (short) pro.pcb.getcount());
                pro.pcb.reg.set_spl_reg((short) 4, (short) 0);
                pro.pcb.reg.set_spl_reg((short) 5, (short) 0);
                pro.pcb.reg.set_spl_reg((short) 6, (short) 0);
                pro.pcb.reg.set_spl_reg((short) 7, (short) 0);
                pro.pcb.reg.set_spl_reg((short) 8, (short) pro.pcb.getdatasize());
                short c, c1;
                do {
                        i += 2;
                        p += 2;
                        c = pro.pcb.reg.get_spl_reg((short) 3);   //counter for code
                        c1 = pro.pcb.reg.get_spl_reg((short) 2);
                        Fetch_Decode();
                        String pid = String.valueOf(p1.pcb.getpid());       // writing in text files
                        String insno = String.valueOf(p1.pcb.getinstcounter());
                        p1.pcb.incinstcounter();
                        String log = pid + ": Instruction # " + insno + " executing";
                        mklogtxt(log);

                        String gantt = "Clock Cycle :" + p + " - " + pid;
                        mkganttchartxt(gantt);
                } while (c < c1 - 1);

                pro.pcb.reg.set_spl_reg((short) 3, (short) 0);
                terminate(pro);
        }

        void execute() throws Exception { //execute all functions
                //p1.LoadProcess("p3.proc");
                //p1.LoadProcess("p2.proc");
                short c, c1;

                System.out.println("execution starts");

                while (!q1.isEmpty()) {
                        i += 4;

                        p1 = q1.deArrayList();
                        p1.pcb.reg.set_spl_reg((short) 0, (short) 0);     //update gen purpose register
                        p1.pcb.reg.set_spl_reg((short) 1, (short) 0);
                        p1.pcb.reg.set_spl_reg((short) 2, (short) p1.pcb.getcodesize());
                        p1.pcb.reg.set_spl_reg((short) 3, (short) p1.pcb.getcount());
                        p1.pcb.reg.set_spl_reg((short) 4, (short) 0);
                        p1.pcb.reg.set_spl_reg((short) 5, (short) 0);
                        p1.pcb.reg.set_spl_reg((short) 6, (short) 0);
                        p1.pcb.reg.set_spl_reg((short) 7, (short) 0);
                        p1.pcb.reg.set_spl_reg((short) 8, (short) p1.pcb.getdatasize());

                        p += 2;

                        c = p1.pcb.reg.get_spl_reg((short) 3);   //counter for code
                        c1 = p1.pcb.reg.get_spl_reg((short) 2);  //limit of code
                        Fetch_Decode();

                        String pid = String.valueOf(p1.pcb.getpid());       // writing in text files
                        String insno = String.valueOf(p1.pcb.getinstcounter());
                        p1.pcb.incinstcounter();
                        String log = pid + ": Instruction # " + insno + " executing";
                        mklogtxt(log);

                        String gantt = "Clock Cycle :" + p + " - " + pid;
                        mkganttchartxt(gantt);

                        p += 2;
                        c = p1.pcb.reg.get_spl_reg((short) 3);  //counter for code
                        c1 = p1.pcb.reg.get_spl_reg((short) 2);  //counter for limit
                        Fetch_Decode();

                        insno = String.valueOf(p1.pcb.getinstcounter());   //writing in text files
                        p1.pcb.incinstcounter();
                        log = pid + ": Instruction # " + insno + " executing";
                        mklogtxt(log);

                        gantt = "Clock Cycle :" + p + " - " + pid;
                        mkganttchartxt(gantt);

                        if (c < c1 - 1) {
                                q1.enArrayList(p1);
                                p1.pcb.setcount(p1.pcb.reg.get_spl_reg((short) 3));
                        } //cgk if func ends
                        else {
                                terminate(p1);
                        }

                        System.out.println(p1.pcb.getpfilename());

                        log = "Context Switching";
                        mklogtxt(log);
                } //execute func ends

                p1.pcb.reg.set_spl_reg((short) 3, (short) 0);
        }

        void terminate(Process p) { //terminate func
                int i = 0;
                while (i < 20) {
                        if (p.pcb.codept.getflag(i) == 1) {
                                int f = p.pcb.codept.delf(i);
                                p.mem1.memtable.setf(0, f);
                        }
                        i++;
                }
                i = 0;
                while (i < 20) {
                        if (p.pcb.datapt.getflag(i) == 1) {
                                int f = p.pcb.datapt.delf(i);
                                p.mem1.memtable.setf(0, f);
                        }
                        i++;
                }
                Process p2 = new Process();
                for (int c = 0; c < q1.size(); c++) {
                        p2 = q1.deArrayList();
                        if (p2.pcb.pid != p.pcb.pid) {
                                q1.enArrayList(p2);
                        } else {
                                break;
                        }
                }

                for (int c = 0; c < q2.size(); c++) {
                        p2 = q2.deArrayList();
                        if (p2.pcb.pid != p.pcb.pid) {
                                q2.enArrayList(p2);
                        } else {
                                break;
                        }
                }

        } //terminate

        void cflag() //the function that breaks the flag register into bits
        {
                short val1 = 0; //value of carry in 0th bit of flag register
                short val2 = 1; //value of carry in 1st bit of flag register
                short val3 = 2; //value of carry in 2nd bit of flag register
                short val4 = 3; //value of carry in 3rd bit of flag register
                carry = p1.pcb.reg.get_flag_val(val1);  //getting value from flag register
                zero = p1.pcb.reg.get_flag_val(val2);
                sign = p1.pcb.reg.get_flag_val(val3);
                overflow = p1.pcb.reg.get_flag_val(val4);

        }

        void mksummary() { // making Process-Summary.txt
                try {
                        BufferedWriter out = new BufferedWriter(new FileWriter("Process Summary.txt"));
                        Process pw = new Process();
                        while (!sp.isEmpty()) {
                                pw = sp.deArrayList();
                                out.write("Process ID: " + pw.pcb.getpid() + "\r\n");
                                out.write("==================" + "\r\n" + "\r\n");
                                out.write("No. of Register-Register Instructions: " + pw.pcb.getregreg() + "\r\n");
                                out.write("No. of Register-Immediate Instructions: " + pw.pcb.getregimd() + "\r\n");
                                out.write("No. of Memory Instructions: " + pw.pcb.getmem() + "\r\n");
                                out.write("No. of Single Operand Instructions: " + pw.pcb.getsgop() + "\r\n");
                                out.write("No. of No Operand Instructions: " + pw.pcb.getnoop() + "\r\n");
                                int total = pw.pcb.getregreg() + pw.pcb.getregimd() + pw.pcb.getmem() + pw.pcb.getsgop()
                                        + pw.pcb.getnoop();
                                out.write("Toatal No. of Instructions: " + total + "\r\n" + "\r\n" + "\r\n" + "\r\n" + "\r\n");

                        }

                        out.close();
                } catch (Exception e) {
                }
        } //ends

        void mklogtxt(String s) throws Exception { // making log.txt
                BufferedWriter out1 = new BufferedWriter(new FileWriter("log.txt", true));
                out1.write(s + "\r\n" + "\r\n");
                out1.close();
        } //ends

        void mkganttchartxt(String s) throws Exception { //making gantt chart.txt
                BufferedWriter out2 = new BufferedWriter(new FileWriter("Gantt Chart.txt", true));
                out2.write(s + "\r\n" + "\r\n");
                out2.close();
        } //ends

}
