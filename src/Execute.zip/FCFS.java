/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package osvm;

/**
 *
 * @author Ashad Nadeem
 */
class Node {

        PCB data;
        Node next;

        Node() {
                this.data = null;
                this.next = null;
        }

        Node(PCB data) {
                this.data = data;
                this.next = null;
        }
}

class FCFS {
//        implemet first come first served

        private Node front;
        private Node rear;

        FCFS() { //constructor
                Node tmp = new Node();
                front = tmp;
                rear = tmp;
        }

        public void enqueue(PCB data) {
                //insert in the queue
                Node tmp = new Node(data);
                if (isEmpty()) {
                        front = tmp;
                        rear = tmp;
                        return;
                }
                rear.next = tmp;
                rear = tmp;
        }

        public PCB dequeue() {
                //remove from queue
                PCB tobereturn = null;
                if (isEmpty()) {
                        System.err.println("Queue is Empty, Cannot DeQueue");
                } else {
                        tobereturn = front.data;
                        front = front.next;
                        if (front == null) {
                                rear = null;
                        }
                }
                return tobereturn;
        }

        public Object seek_front() { //returns data of the data at front
                return front.data;
        }

        public Boolean isEmpty() {
                //returns true if queue is empty
                return (front.data == null);
        }

        public void Display() {
                //prints the queue
                Node curr = front;
                System.out.println("Displaying Nodes");
                while (curr != null) {
                        System.out.println(curr.data);
                        curr = curr.next;
                }
                System.out.println();
        }

        public void put_front(PCB data) {
                //puts data at front
                Node tmp = new Node(data);
                tmp.next = front;
                front = tmp;
        }

        public Object get_rear() {
                //gets data from rear
                Object tobereturn = null;
                if (isEmpty()) {
                        System.err.println("Queue is Empty, Cannot DeQueue");
                } else {
                        Node curr = front;
                        while (curr.next != rear) {
                                curr = curr.next;
                        }
                        tobereturn = rear.data;
                        curr.next = null;
                        rear = curr;
                }
                return tobereturn;
        }
}
